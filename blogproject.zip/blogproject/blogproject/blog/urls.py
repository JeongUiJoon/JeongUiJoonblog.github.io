from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('new/', views.new, name='new'),
    path('create/', views.create, name='create'),
    path('update_page/<int:blog_id>/', views.update_page, name='update_page'),
    path('update/<int:blog_id>', views.update, name='update'),
    path('delete/<int:blog_id>', views.delete, name='delete'),
]