from django.shortcuts import render, redirect, get_object_or_404
from blog.models import Blog
from django.utils import timezone

def index(request):
    blogs= Blog.objects
    return render(request, 'index.html', {'blogs':blogs})
def new(request):
    return render(request, 'new.html') 

def create(request):
    blog = Blog()
    blog.title = request.GET['title']
    blog.body = request.GET['body']
    blog.pub_date = timezone.datetime.now()
    blog.save()
    return redirect('index')


def update_page(request, blog_id):
    update_page = get_object_or_404(Blog, pk=blog_id)
    return render(request, 'update.html', {'blog':update_page})

def update(request, blog_id):
    blog = get_object_or_404(Blog, pk=blog_id)
    blog.title = request.GET['title']
    blog.body = request.GET['body']
    blog.save()
    return redirect('index')

def delete(request, blog_id):
    blog = get_object_or_404(Blog, pk=blog_id)
    blog.delete()
    return redirect('index')

# Create your views here.
